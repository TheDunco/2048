'''
Expanding circles - base code ...

Created on Nov 17, 2014
Updated Summer, 2015

@author smn4
@author kvlinden
'''
from tkinter import *
from random import randint

def get_random_color():
    ''' Generate random color intensities for red, green & blue and convert them to hex. '''
    return '#{:02X}{:02X}{:02X}'.format(randint(0, 255), randint(0, 255), randint(0, 255))

class CircleAnimation:
        
    def __init__(self, window):
        self._window = window
        self._window.protocol('WM_DELETE_WINDOW', self.safe_exit)    
        
        WIDTH = 250
        HEIGHT = WIDTH
        canvas = Canvas(self._window,
                        background='white',
                        width=WIDTH,
                        height=HEIGHT)
        canvas.pack()
                
    def safe_exit(self):
        ''' Terminate the animation before shutting down the GUI window. '''
        self._terminated = True
        self._window.destroy()
        
        
if __name__ == '__main__':
    root = Tk()
    root.title('Those crazy circles...')    
    app = CircleAnimation(root)
    root.mainloop()
